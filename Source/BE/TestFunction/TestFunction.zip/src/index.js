const dynamo = new AWS.DynamoDB.DocumentClient();
exports.handler = async (event) => {
    var data = getData();
    const response = {
        statusCode: 200,
        body: data,
    };
    return response;
};
function getData()
{
    return await dynamo.scan({ TableName: "http-crud-tutorial-items" }).promise();
}